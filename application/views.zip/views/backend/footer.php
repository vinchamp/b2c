<div class="copy">
            <p> &copy; 2016 Buildmyhome.com All Rights Reserved </a> </p>
	    </div>
		</div>
		<div class="clearfix"> </div>
       </div>
     </div>

<!--scrolling js-->
	<script src="<?php echo base_url();?>assets/admin/js/jquery.nicescroll.js"></script>
	<script src="<?php echo base_url();?>assets/admin/js/scripts.js"></script>
	
	<!--//scrolling js-->
	<script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"> </script>
	<script type="text/javascript">
  $('select').select2();
</script>
</body>
</html>

