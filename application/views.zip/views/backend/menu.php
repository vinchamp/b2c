 <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
				
                    <li>
                        <a href="<?php echo base_url('admin/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboard</span> </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('category_management/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-bookmark nav_icon "></i><span class="nav-label">Category </span> </a>
                    </li>
							
                             <li>
                        <a href="<?php echo base_url('product/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-product-hunt nav_icon "></i><span class="nav-label">Product </span> </a>
                    </li>

					<li>
                        <a href="<?php echo base_url('header/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-header nav_icon "></i><span class="nav-label">Header</span> </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('footer/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-bars nav_icon "></i><span class="nav-label">Footer</span> </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('banners/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-image nav_icon "></i><span class="nav-label">Banners</span> </a>
                    
					</li>
					<li>
                        <a href="<?php echo base_url('pages/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-pencil-square-o nav_icon "></i><span class="nav-label">Pages</span> </a>
                    
                    </li>
					<li>
                        <a href="<?php echo base_url('users/users');?>" class=" hvr-bounce-to-right"><i class="fa fa-sign-in nav_icon "></i><span class="nav-label">Customer</span> </a>
                    
                    </li>
					<li>
                        <a href="<?php echo base_url('suppliers/suppliers');?>" class=" hvr-bounce-to-right"><i class="fa fa-user nav_icon "></i><span class="nav-label">Supplier</span> </a>
                    
                    </li>
                    <li>
                        <a href="<?php echo base_url('trusted_clients/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-connectdevelop nav_icon "></i><span class="nav-label">Trusted Clients Images </span> </a>
                    
                    </li>
					<li><a href="<?php echo base_url('notification/admin');?>"  class=" hvr-bounce-to-right" data-target=".site-menu" data-toggle="collapse"><i class="fa fa-bell nav_icon "></i> Notification<i class="fa fa-collapse"></i></a></li>
					<li>
					
					
                    <!--li>
                        <a href="<?php echo base_url('menu/admin');?>" class=" hvr-bounce-to-right"><i class="fa fa-user nav_icon "></i><span class="nav-label">Sub Category Management</span> </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo base_url('chapter_pages/chapter_pages');?>" class=" hvr-bounce-to-right"><i class="fa fa-user nav_icon "></i><span class="nav-label">Advertisment Management</span> </a>
						<ul class="nav" id="side-menu">
							<li>
                        <a href="<?php echo base_url('chapter_pages/chapter_pages');?>" class=" hvr-bounce-to-right"><i class="fa fa-user nav_icon "></i><span class="nav-label">Manage Ad Images</span> </a>
							</li>
							<li>
                        <a href="<?php echo base_url('chapter_pages/chapter_pages');?>" class=" hvr-bounce-to-right"><i class="fa fa-user nav_icon "></i><span class="nav-label">Manage Ad Content</span> </a>
							</li>
							
						</ul>
                    </li-->
                </ul>
            </div>
			</div>
        </nav>