<?php $this->load->view('frontend/header');?>
<div class="container">
				<div class="mid-section">
						<div class="mid-top wow fadeInUpBig animated animated" data-wow-delay="0.4s">
							<div class="col-md-10 mid-text">
							 <center><em>   &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp                                                                                                    </em>	<img src="<?php echo base_url('assets/admin/images/404-page-4.jpg'); ?>" width="79%" height="90%">
						</center>
							</div>
							
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<?php $this->load->view('frontend/footer');?>